import markdown

html = markdown.markdown("**rishi**")

print(html)